import java.util.Scanner;

public class ElectronicsAndAppliances {

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Display options with an extra line space for readability
            System.out.println("\nChoose an option:");
            System.out.println("1. Select Outlet Extension and Appliances");
            System.out.println("2. View Electronic Details");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();

            System.out.println(); // Additional line break for readability

            switch (choice) {
                case 1:
                    selectOutletAndAppliance(scanner);
                    break;
                case 2:
                    viewElectronicDetails(scanner);
                    break;
                case 3:
                    System.out.println("Exiting the program...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.\n");
            }
        }
    }

    // Method for Option 1: Selecting Outlet Extension and Appliances
    public static void selectOutletAndAppliance(Scanner scanner) {
        // Updated extensions
        String[] extensions = { "3 Outlet Extension", "4 Outlet Extension", "5 Outlet Extension" };
        int extensionWattage = 2500;  // All extensions have a maximum wattage of 2500

        // Display extension options with extra line space
        System.out.println("\nSelect an outlet extension:");
        for (int i = 0; i < extensions.length; i++) {
            System.out.println((i + 1) + ". " + extensions[i]);
        }

        int extensionChoice = scanner.nextInt();
        System.out.println(); // Additional line break for readability

        if (extensionChoice < 1 || extensionChoice > extensions.length) {
            System.out.println("Invalid extension choice.\n");
            return;
        }

        // Number of appliances based on selected extension
        int outlets = extensionChoice + 2;  // 3 outlets for choice 1, 4 for choice 2, 5 for choice 3
        System.out.println("You selected: " + extensions[extensionChoice - 1]);
        System.out.println("You can select up to " + outlets + " appliances.\n");

        // Appliances with their wattages
        String[] appliances = { "Fan", "Heater", "TV", "Fridge", "Microwave", "Air Conditioner", "Washing Machine", "Toaster" };
        int[] applianceWattages = { 75, 1500, 250, 800, 1000, 1500, 500, 800 };  // Wattage for each appliance

        // Display appliances with extra line space
        System.out.println("Available appliances and their wattages:");
        for (int i = 0; i < appliances.length; i++) {
            System.out.println((i + 1) + ". " + appliances[i] + " (" + applianceWattages[i] + "W)");
        }

        int totalWattage = 0;
        for (int i = 0; i < outlets; i++) {
            System.out.println("\nSelect appliance #" + (i + 1) + ":");
            int applianceChoice = scanner.nextInt();
            System.out.println(); // Additional line break for readability

            if (applianceChoice < 1 || applianceChoice > appliances.length) {
                System.out.println("Invalid appliance choice.\n");
            } else {
                totalWattage += applianceWattages[applianceChoice - 1];
                System.out.println("You selected: " + appliances[applianceChoice - 1] + " (" + applianceWattages[applianceChoice - 1] + "W)\n");
            }
        }

        // Check if total wattage exceeds 80% of the extension's wattage
        double wattageLimit = 0.8 * extensionWattage;  // 80% of 2500 watts
        if (totalWattage > wattageLimit) {
            System.out.println("Warning: You are exceeding the wattage recommendation! Total wattage: " + totalWattage + "W\n");
        } else {
            System.out.println("Total wattage of selected appliances: " + totalWattage + "W\n");
        }
    }

    // Method for Option 2: Viewing Electronic Details
    public static void viewElectronicDetails(Scanner scanner) {
        // Expanded electronics list with more options
        String[] electronics = { 
            "Laptop", "Smartphone", "Television", "Microwave", "Washing Machine", 
            "Air Conditioner", "Blender", "Refrigerator"
        };

        // Display electronic options with an extra line space
        System.out.println("\nSelect an electronic to view details:");
        for (int i = 0; i < electronics.length; i++) {
            System.out.println((i + 1) + ". " + electronics[i]);
        }

        int electronicChoice = scanner.nextInt();
        System.out.println(); // Additional line break for readability

        if (electronicChoice < 1 || electronicChoice > electronics.length) {
            System.out.println("Invalid electronic choice.\n");
            return;
        }

        // Details of selected electronic
        switch (electronicChoice) {
            case 1:
                displayElectronicDetails("Laptop", "Dell", 65, "Great for office work and gaming.");
                break;
            case 2:
                displayElectronicDetails("Smartphone", "Samsung", 15, "Excellent camera and battery life.");
                break;
            case 3:
                displayElectronicDetails("Television", "Sony", 120, "Crystal-clear picture quality.");
                break;
            case 4:
                displayElectronicDetails("Microwave", "LG", 1000, "Fast and efficient heating.");
                break;
            case 5:
                displayElectronicDetails("Washing Machine", "Whirlpool", 500, "Efficient for laundry with multiple cycles.");
                break;
            case 6:
                displayElectronicDetails("Air Conditioner", "Samsung", 2000, "Cool and dehumidify the room efficiently.");
                break;
            case 7:
                displayElectronicDetails("Blender", "Ninja", 1200, "Perfect for smoothies and food preparation.");
                break;
            case 8:
                displayElectronicDetails("Refrigerator", "LG", 150, "Energy-efficient with multiple compartments.");
                break;
        }
    }

    // Method to display details of selected electronic
    public static void displayElectronicDetails(String name, String brand, int wattage, String review) {
        System.out.println("\nElectronic Details:");
        System.out.println("Name: " + name);
        System.out.println("Brand: " + brand);
        System.out.println("Wattage: " + wattage + " watts");
        System.out.println("Review: " + review + "\n");
    }
}
